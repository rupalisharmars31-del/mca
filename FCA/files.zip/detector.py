"""
Face Detection Module
----------------------
Wraps OpenCV's DNN-based face detector (SSD/ResNet10, Caffe model).
This is more robust than Haar cascades to pose, lighting, and partial occlusion.

Model files (download once, ~5MB total):
  - deploy.prototxt
  - res10_300x300_ssd_iter_140000.caffemodel

Both are part of OpenCV's official sample models repo:
  https://github.com/opencv/opencv/tree/master/samples/dnn/face_detector

Fallback: if the DNN model files are not found, this module automatically
falls back to a Haar Cascade (bundled with opencv-python), so the pipeline
still runs out of the box.
"""

import os
import cv2
import numpy as np


class FaceDetector:
    def __init__(self, model_dir="models/face_detector", conf_threshold=0.6):
        self.conf_threshold = conf_threshold
        self.net = None
        self.mode = "haar"

        prototxt = os.path.join(model_dir, "deploy.prototxt")
        weights = os.path.join(model_dir, "res10_300x300_ssd_iter_140000.caffemodel")

        if os.path.exists(prototxt) and os.path.exists(weights):
            self.net = cv2.dnn.readNetFromCaffe(prototxt, weights)
            self.mode = "dnn"
        else:
            # Fallback to Haar cascade shipped with opencv-python
            cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            self.haar = cv2.CascadeClassifier(cascade_path)
            print(
                "[FaceDetector] DNN model files not found in "
                f"'{model_dir}'. Falling back to Haar cascade.\n"
                "For better accuracy, download deploy.prototxt and "
                "res10_300x300_ssd_iter_140000.caffemodel into that folder."
            )

    def detect(self, frame):
        """
        Returns a list of bounding boxes: [(x1, y1, x2, y2, confidence), ...]
        """
        h, w = frame.shape[:2]
        boxes = []

        if self.mode == "dnn":
            blob = cv2.dnn.blobFromImage(
                cv2.resize(frame, (300, 300)), 1.0, (300, 300),
                (104.0, 177.0, 123.0)
            )
            self.net.setInput(blob)
            detections = self.net.forward()

            for i in range(detections.shape[2]):
                confidence = detections[0, 0, i, 2]
                if confidence > self.conf_threshold:
                    box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                    x1, y1, x2, y2 = box.astype(int)
                    x1, y1 = max(0, x1), max(0, y1)
                    x2, y2 = min(w - 1, x2), min(h - 1, y2)
                    boxes.append((x1, y1, x2, y2, float(confidence)))
        else:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.haar.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40)
            )
            for (x, y, fw, fh) in faces:
                boxes.append((x, y, x + fw, y + fh, 1.0))

        return boxes

    @staticmethod
    def crop_face(frame, box, margin=0.2):
        """Crop a face region with a margin, clipped to image bounds."""
        h, w = frame.shape[:2]
        x1, y1, x2, y2 = box[:4]
        bw, bh = x2 - x1, y2 - y1
        mx, my = int(bw * margin), int(bh * margin)
        x1 = max(0, x1 - mx)
        y1 = max(0, y1 - my)
        x2 = min(w, x2 + mx)
        y2 = min(h, y2 + my)
        return frame[y1:y2, x1:x2]
