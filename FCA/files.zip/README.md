# Facial Analysis: Emotion, Age & Gender

A computer vision pipeline that detects faces in an image, webcam feed, or
video, and predicts for each face:

- **Emotion / mood** — 7 classes: Angry, Disgust, Fear, Happy, Sad, Surprise, Neutral
- **Age** — estimated age in years (regression)
- **Gender** — Male / Female

## Project structure

```
facial_analysis/
├── detector.py      # Face detection (OpenCV DNN, falls back to Haar cascade)
├── models.py         # CNN architectures for emotion / age / gender
├── train.py          # Training scripts for each model
├── inference.py       # Real-time / image / video inference pipeline
├── requirements.txt
└── checkpoints/       # Trained model weights land here (.h5 files)
```

## 1. Setup

```bash
pip install -r requirements.txt
```

(Optional, better face detection) Download the OpenCV DNN face detector files
into `models/face_detector/`:
- `deploy.prototxt`
- `res10_300x300_ssd_iter_140000.caffemodel`
from https://github.com/opencv/opencv/tree/master/samples/dnn/face_detector

If you skip this, the pipeline automatically falls back to a Haar Cascade
detector (already bundled with `opencv-python`) — slightly less accurate on
angled/occluded faces but works with zero extra downloads.

## 2. Datasets

| Task            | Dataset  | Link |
|-----------------|----------|------|
| Emotion         | FER2013  | https://www.kaggle.com/datasets/msambare/fer2013 |
| Age & Gender    | UTKFace  | https://susanqq.github.io/UTKFace/ |

FER2013 comes as a single CSV (`pixels`, `emotion`, `usage` columns).
UTKFace comes as individual images named `{age}_{gender}_{race}_{timestamp}.jpg`.

## 3. Training

```bash
# Emotion model
python train.py --task emotion --data_path data/fer2013.csv --epochs 40

# Age + Gender models (trained together, saved separately)
python train.py --task age_gender --data_path data/UTKFace --epochs 30
```

Best checkpoints (by validation metric) are saved to `checkpoints/`:
`emotion_best.h5`, `age_best.h5`, `gender_best.h5`.

Each model can also be trained/used independently — the pipeline gracefully
skips any attribute whose checkpoint isn't found yet.

## 4. Running inference

```bash
# Live webcam
python inference.py --source webcam

# Single image -> saves annotated_<filename>
python inference.py --source image --path photo.jpg

# Video file -> saves annotated_output.mp4
python inference.py --source video --path clip.mp4
```

Each detected face gets a bounding box with gender, estimated age, and
predicted emotion + confidence drawn above it.

## 5. Architecture notes

- All three models share a similar lightweight CNN backbone
  (`build_backbone` in `models.py`) sized for 96×96 grayscale input —
  fast enough for real-time webcam inference on CPU.
- `build_multitask_model()` offers a single shared-backbone, multi-head
  variant (one forward pass instead of three) if you'd rather train and
  serve one model instead of three. Combine losses as:
  `categorical_crossentropy` (emotion) + `mse` (age) + `categorical_crossentropy` (gender),
  weighted e.g. `[1.0, 0.05, 1.0]` since age (in years) has a much larger
  raw loss scale than the classification tasks.
- `build_transfer_backbone()` swaps in a frozen MobileNetV2 for transfer
  learning if you have less training data — needs RGB 96×96×3 input instead
  of grayscale.

## 6. Accuracy expectations (typical, not guaranteed)

- Emotion (FER2013, from scratch): ~65-70% accuracy — FER2013 itself has
  noisy/ambiguous labels, so this is close to the practical ceiling for
  small custom CNNs on this dataset.
- Age (UTKFace): ~5-7 years MAE.
- Gender (UTKFace): ~92-95% accuracy.

Transfer learning, larger backbones, and ensembling can push these further.

## 7. Ethical & practical considerations

- **Emotion is expression, not felt experience.** These models predict the
  *facial expression* pattern, which is a proxy and doesn't reliably equal
  a person's actual internal emotional state — treat outputs as probabilistic
  signals, not ground truth about how someone feels.
- **Bias**: public face datasets (FER2013, UTKFace) are not perfectly
  balanced across skin tone, age range, or gender presentation. Validate
  accuracy across subgroups on your own data before deploying in any
  consequential context (hiring, security, healthcare, etc.).
- **Consent & privacy**: if used on real people (beyond your own test
  photos/webcam), make sure you have a lawful basis and clear consent,
  particularly given biometric-data regulations (e.g., GDPR, BIPA) that
  apply in many jurisdictions.
