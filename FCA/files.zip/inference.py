"""
Inference Pipeline
--------------------
Combines FaceDetector + the three trained models into a single pipeline that:
  1. Detects all faces in a frame/image
  2. Crops + preprocesses each face
  3. Predicts emotion, age, and gender per face
  4. Draws annotated bounding boxes + labels

Usage:
  # Webcam (live)
  python inference.py --source webcam

  # Single image
  python inference.py --source image --path photo.jpg

  # Video file
  python inference.py --source video --path clip.mp4
"""

import argparse
import cv2
import numpy as np
import tensorflow as tf

from detector import FaceDetector
from models import EMOTION_LABELS, GENDER_LABELS, IMG_SIZE

CHECKPOINT_DIR = "checkpoints"


class FaceAnalyzer:
    def __init__(self, checkpoint_dir=CHECKPOINT_DIR):
        self.detector = FaceDetector()
        self.emotion_model = self._safe_load(f"{checkpoint_dir}/emotion_best.h5")
        self.age_model = self._safe_load(f"{checkpoint_dir}/age_best.h5")
        self.gender_model = self._safe_load(f"{checkpoint_dir}/gender_best.h5")

    @staticmethod
    def _safe_load(path):
        try:
            return tf.keras.models.load_model(path)
        except (OSError, IOError):
            print(f"[FaceAnalyzer] Warning: could not load {path}. "
                  "Train the model first (see train.py). Predictions for "
                  "this attribute will be skipped.")
            return None

    @staticmethod
    def _preprocess(face_img):
        gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
        normalized = resized.astype("float32") / 255.0
        return normalized.reshape(1, IMG_SIZE, IMG_SIZE, 1)

    def analyze_face(self, face_img):
        """Returns dict with emotion, age, gender predictions (whichever models are loaded)."""
        x = self._preprocess(face_img)
        result = {}

        if self.emotion_model is not None:
            probs = self.emotion_model.predict(x, verbose=0)[0]
            idx = int(np.argmax(probs))
            result["emotion"] = EMOTION_LABELS[idx]
            result["emotion_confidence"] = float(probs[idx])
            result["emotion_probs"] = {
                label: float(p) for label, p in zip(EMOTION_LABELS, probs)
            }

        if self.age_model is not None:
            pred_age = self.age_model.predict(x, verbose=0)[0][0]
            result["age"] = int(round(float(pred_age)))

        if self.gender_model is not None:
            probs = self.gender_model.predict(x, verbose=0)[0]
            idx = int(np.argmax(probs))
            result["gender"] = GENDER_LABELS[idx]
            result["gender_confidence"] = float(probs[idx])

        return result

    def analyze_frame(self, frame):
        """Detect all faces in a frame and analyze each. Returns list of (box, attributes)."""
        boxes = self.detector.detect(frame)
        results = []
        for box in boxes:
            face_crop = self.detector.crop_face(frame, box)
            if face_crop.size == 0:
                continue
            attrs = self.analyze_face(face_crop)
            results.append((box, attrs))
        return results

    @staticmethod
    def draw_annotations(frame, results):
        for box, attrs in results:
            x1, y1, x2, y2, conf = box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 220, 0), 2)

            lines = []
            if "gender" in attrs:
                lines.append(f"{attrs['gender']} ({attrs['gender_confidence']*100:.0f}%)")
            if "age" in attrs:
                lines.append(f"Age: {attrs['age']}")
            if "emotion" in attrs:
                lines.append(f"{attrs['emotion']} ({attrs['emotion_confidence']*100:.0f}%)")

            for i, line in enumerate(lines):
                y_offset = y1 - 10 - (len(lines) - 1 - i) * 18
                y_offset = max(15, y_offset)
                cv2.putText(frame, line, (x1, y_offset),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 0), 2)
        return frame


def run_webcam(analyzer):
    cap = cv2.VideoCapture(0)
    print("Press 'q' to quit.")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        results = analyzer.analyze_frame(frame)
        frame = analyzer.draw_annotations(frame, results)
        cv2.imshow("Face Analysis", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    cap.release()
    cv2.destroyAllWindows()


def run_image(analyzer, path):
    frame = cv2.imread(path)
    if frame is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    results = analyzer.analyze_frame(frame)
    for box, attrs in results:
        print(box, attrs)
    frame = analyzer.draw_annotations(frame, results)
    out_path = "annotated_" + path.split("/")[-1]
    cv2.imwrite(out_path, frame)
    print(f"Saved annotated image to {out_path}")


def run_video(analyzer, path):
    cap = cv2.VideoCapture(path)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    out = cv2.VideoWriter("annotated_output.mp4", fourcc, fps, (w, h))

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        results = analyzer.analyze_frame(frame)
        frame = analyzer.draw_annotations(frame, results)
        out.write(frame)

    cap.release()
    out.release()
    print("Saved annotated video to annotated_output.mp4")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["webcam", "image", "video"], required=True)
    parser.add_argument("--path", help="Path to image/video file (not needed for webcam)")
    args = parser.parse_args()

    analyzer = FaceAnalyzer()

    if args.source == "webcam":
        run_webcam(analyzer)
    elif args.source == "image":
        run_image(analyzer, args.path)
    elif args.source == "video":
        run_video(analyzer, args.path)
