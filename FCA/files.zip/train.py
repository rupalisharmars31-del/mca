"""
Training Script
-----------------
Trains the emotion, age, and gender models on standard public datasets:

  - Emotion: FER2013 (Kaggle) - CSV with columns [emotion, pixels, usage]
             https://www.kaggle.com/datasets/msambare/fer2013
  - Age/Gender: UTKFace - filenames encode labels as "{age}_{gender}_{race}_{date}.jpg"
             https://susanqq.github.io/UTKFace/

Usage:
  python train.py --task emotion --data_path data/fer2013.csv --epochs 40
  python train.py --task age_gender --data_path data/UTKFace --epochs 30

Both trainers save the best checkpoint (by validation metric) to `checkpoints/`.
"""

import os
import argparse
import numpy as np
import pandas as pd
import cv2
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.utils import to_categorical

from models import build_emotion_model, build_age_model, build_gender_model, IMG_SIZE

CHECKPOINT_DIR = "checkpoints"
os.makedirs(CHECKPOINT_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_fer2013(csv_path):
    df = pd.read_csv(csv_path)
    pixels = df["pixels"].apply(lambda p: np.array(p.split(), dtype="float32"))
    X = np.stack(pixels.values)
    X = X.reshape(-1, 48, 48, 1)
    X = np.array([cv2.resize(img, (IMG_SIZE, IMG_SIZE)) for img in X])
    X = X.reshape(-1, IMG_SIZE, IMG_SIZE, 1) / 255.0
    y = to_categorical(df["emotion"].values, num_classes=7)
    return train_test_split(X, y, test_size=0.15, random_state=42, stratify=df["emotion"])


def load_utkface(folder_path):
    images, ages, genders = [], [], []
    for fname in os.listdir(folder_path):
        if not fname.lower().endswith((".jpg", ".png")):
            continue
        try:
            age, gender = fname.split("_")[0:2]
            age, gender = int(age), int(gender)  # gender: 0=male, 1=female
        except (ValueError, IndexError):
            continue
        img = cv2.imread(os.path.join(folder_path, fname), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
        images.append(img)
        ages.append(age)
        genders.append(gender)

    X = np.array(images).reshape(-1, IMG_SIZE, IMG_SIZE, 1) / 255.0
    ages = np.array(ages, dtype="float32")
    genders = to_categorical(np.array(genders), num_classes=2)

    return train_test_split(X, ages, genders, test_size=0.15, random_state=42)


# ---------------------------------------------------------------------------
# Training routines
# ---------------------------------------------------------------------------
def train_emotion(data_path, epochs, batch_size):
    X_train, X_val, y_train, y_val = load_fer2013(data_path)
    model = build_emotion_model()
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

    ckpt = ModelCheckpoint(
        os.path.join(CHECKPOINT_DIR, "emotion_best.h5"),
        monitor="val_accuracy", save_best_only=True, verbose=1
    )
    callbacks = [
        ckpt,
        EarlyStopping(monitor="val_accuracy", patience=8, restore_best_weights=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4),
    ]

    datagen = tf.keras.preprocessing.image.ImageDataGenerator(
        rotation_range=10, width_shift_range=0.1, height_shift_range=0.1,
        zoom_range=0.1, horizontal_flip=True
    )
    model.fit(
        datagen.flow(X_train, y_train, batch_size=batch_size),
        validation_data=(X_val, y_val),
        epochs=epochs,
        callbacks=callbacks,
    )
    print("Saved best emotion model to checkpoints/emotion_best.h5")


def train_age_gender(data_path, epochs, batch_size):
    X_train, X_val, age_train, age_val, gender_train, gender_val = load_utkface(data_path)

    # Age model
    age_model = build_age_model()
    age_model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    age_ckpt = ModelCheckpoint(
        os.path.join(CHECKPOINT_DIR, "age_best.h5"),
        monitor="val_mae", save_best_only=True, verbose=1
    )
    age_model.fit(
        X_train, age_train, validation_data=(X_val, age_val),
        epochs=epochs, batch_size=batch_size,
        callbacks=[age_ckpt, EarlyStopping(monitor="val_mae", patience=8, restore_best_weights=True)],
    )

    # Gender model
    gender_model = build_gender_model()
    gender_model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    gender_ckpt = ModelCheckpoint(
        os.path.join(CHECKPOINT_DIR, "gender_best.h5"),
        monitor="val_accuracy", save_best_only=True, verbose=1
    )
    gender_model.fit(
        X_train, gender_train, validation_data=(X_val, gender_val),
        epochs=epochs, batch_size=batch_size,
        callbacks=[gender_ckpt, EarlyStopping(monitor="val_accuracy", patience=8, restore_best_weights=True)],
    )
    print("Saved best age/gender models to checkpoints/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=["emotion", "age_gender"], required=True)
    parser.add_argument("--data_path", required=True)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch_size", type=int, default=64)
    args = parser.parse_args()

    if args.task == "emotion":
        train_emotion(args.data_path, args.epochs, args.batch_size)
    else:
        train_age_gender(args.data_path, args.epochs, args.batch_size)
