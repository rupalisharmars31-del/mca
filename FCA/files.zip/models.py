"""
Model Architectures
--------------------
Three CNNs, each independently trainable and loadable:

1. EmotionNet  -> 7-class softmax  (FER2013 labels: angry, disgust, fear,
                  happy, sad, surprise, neutral)
2. AgeNet      -> single-value regression (predicted age in years)
3. GenderNet   -> 2-class softmax (male, female)

All three share a similar mini-Xception / VGG-style backbone that is small
enough to train on a single GPU (or even CPU, slowly) from datasets like
FER2013 (emotion) and UTKFace (age + gender).

You can also swap the backbone for a pretrained one (MobileNetV2, ResNet50)
via `build_transfer_backbone` for better accuracy with less data/time.
"""

import tensorflow as tf
from tensorflow.keras import layers, models, regularizers

EMOTION_LABELS = ["Angry", "Disgust", "Fear", "Happy", "Sad", "Surprise", "Neutral"]
GENDER_LABELS = ["Male", "Female"]

IMG_SIZE = 96  # input resolution used across all three models


def _conv_block(x, filters, kernel_size=3, pool=True, dropout=0.25, l2=1e-4):
    x = layers.Conv2D(filters, kernel_size, padding="same",
                       kernel_regularizer=regularizers.l2(l2))(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation("relu")(x)
    x = layers.Conv2D(filters, kernel_size, padding="same",
                       kernel_regularizer=regularizers.l2(l2))(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation("relu")(x)
    if pool:
        x = layers.MaxPooling2D(pool_size=2)(x)
    x = layers.Dropout(dropout)(x)
    return x


def build_backbone(input_shape=(IMG_SIZE, IMG_SIZE, 1)):
    """Small custom CNN backbone (works well for grayscale FER2013-style input)."""
    inputs = layers.Input(shape=input_shape)
    x = _conv_block(inputs, 32)
    x = _conv_block(x, 64)
    x = _conv_block(x, 128)
    x = _conv_block(x, 256, pool=False)
    x = layers.GlobalAveragePooling2D()(x)
    return inputs, x


def build_transfer_backbone(input_shape=(IMG_SIZE, IMG_SIZE, 3)):
    """MobileNetV2-based backbone for transfer learning (needs RGB input)."""
    base = tf.keras.applications.MobileNetV2(
        input_shape=input_shape, include_top=False, weights="imagenet"
    )
    base.trainable = False  # unfreeze later layers for fine-tuning if desired
    inputs = base.input
    x = layers.GlobalAveragePooling2D()(base.output)
    return inputs, x, base


def build_emotion_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=7):
    inputs, x = build_backbone(input_shape)
    x = layers.Dense(256, activation="relu")(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="emotion")(x)
    return models.Model(inputs, outputs, name="EmotionNet")


def build_age_model(input_shape=(IMG_SIZE, IMG_SIZE, 1)):
    inputs, x = build_backbone(input_shape)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    # Single neuron, linear activation -> regression (predicted age)
    outputs = layers.Dense(1, activation="linear", name="age")(x)
    return models.Model(inputs, outputs, name="AgeNet")


def build_gender_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2):
    inputs, x = build_backbone(input_shape)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="gender")(x)
    return models.Model(inputs, outputs, name="GenderNet")


def build_multitask_model(input_shape=(IMG_SIZE, IMG_SIZE, 1)):
    """
    Optional: single shared backbone with three heads.
    Faster inference (one forward pass) and often better generalization
    since age/gender/emotion share low-level facial features.
    Train with a combined loss: categorical_crossentropy (emotion, gender)
    + mse (age), each weighted.
    """
    inputs, shared = build_backbone(input_shape)

    # Emotion head
    e = layers.Dense(256, activation="relu")(shared)
    e = layers.Dropout(0.5)(e)
    emotion_out = layers.Dense(7, activation="softmax", name="emotion")(e)

    # Age head
    a = layers.Dense(128, activation="relu")(shared)
    a = layers.Dropout(0.3)(a)
    age_out = layers.Dense(1, activation="linear", name="age")(a)

    # Gender head
    g = layers.Dense(128, activation="relu")(shared)
    g = layers.Dropout(0.3)(g)
    gender_out = layers.Dense(2, activation="softmax", name="gender")(g)

    return models.Model(inputs, [emotion_out, age_out, gender_out], name="MultiTaskFaceNet")


if __name__ == "__main__":
    m = build_multitask_model()
    m.summary()
